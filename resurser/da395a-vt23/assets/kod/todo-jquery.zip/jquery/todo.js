let todos = [
    {
        title: "Första saken",
        id: 1
    }
];
let latestID = 1;

$("#new-todo").on("keyup", function (event) {
    if (event.keyCode == 13) {
        let todo = {
            title: event.target.value,
            id: ++latestID
        };
        todos.push(todo);
        $(this).val("")

        renderTodos();
    }
});

function renderTodos() {
    $("#todos").html("");

    for (const todo of todos) {
        $("#todos").append(`
            <li class="list-group-item">
                <label>${todo.title}</label>
                <button class="btn btn-sm btn-danger float-end" data-id="${todo.id}">X</button>
            </li>
        `);
    }
    
    $("body").on("click", ".btn-danger", function () {
        todos = todos.filter(todo => todo.id != $(this).attr("data-id"));
        renderTodos();
    });

    const todoString = todos.length == 1 ? "punkt" : "punkter";
    document.querySelector("#nbr-of-todos").innerHTML = `
        <strong>${todos.length}</strong> ${todoString} kvar att göra.
    `;
};

renderTodos();