var a; // Initaliserad, inget värde
var b = 1; // Initaliserad, har ett värde
let c = true; // Initaliserad, har ett värde
const d = "hello"; // Initaliserad, har ett värde
console.log(a);  // Skriver ut "undefined"
console.log(b); // Skriver ut "1"
console.log(c); // Skriver ut "true"
console.log(d); // Skriver ut "hello"

b = 5;  // Nytt värde!
console.log(b); // Skriver ut "5"

d = "goodbye"; // Här går det fel!
