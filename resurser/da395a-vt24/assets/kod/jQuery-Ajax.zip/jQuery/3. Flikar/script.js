$(".section-1").show();

$("nav li").on("click", function() {
    let id = $(this).attr("id");

    $("section").slideUp(100);
    $(`.${id}`).slideDown(100);

    $("nav li").removeClass("chosen");
    $(this).addClass("chosen");
});