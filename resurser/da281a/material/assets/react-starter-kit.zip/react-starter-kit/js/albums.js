// Vår data (musikalbums)
var albums = [
    {
        "id" : "5Dbax7G8SWrP9xyzkOvy2F",
        "href" : "https://api.spotify.com/v1/albums/5Dbax7G8SWrP9xyzkOvy2F",
        "name" : "The Wall",
        "uri" : "spotify:album:5Dbax7G8SWrP9xyzkOvy2F",
        "image": {
            "height" : 300,
            "url" : "https://i.scdn.co/image/464f49ec36104a5939ea76cf1597a5311d91f602",
            "width" : 300
        }
    },
    {
        "id" : "4LH4d3cOWNNsVw41Gqt2kv",
        "href" : "https://api.spotify.com/v1/albums/4LH4d3cOWNNsVw41Gqt2kv",
        "name" : "The Dark Side of the Moon",
        "uri" : "spotify:album:4LH4d3cOWNNsVw41Gqt2kv",
        "image": {
            "height" : 300,
            "url" : "https://i.scdn.co/image/00a613ea9cf34c561cb5bb4cd62c4bbf907853e3",
            "width" : 300
        }
    },
    {
        "id" : "0bCAjiUamIFqKJsekOYuRw",
        "href" : "https://api.spotify.com/v1/albums/0bCAjiUamIFqKJsekOYuRw",
        "name" : "Wish You Were Here",
        "uri" : "spotify:album:0bCAjiUamIFqKJsekOYuRw",
        "image": {
            "height" : 300,
            "url" : "https://i.scdn.co/image/aab31a87e274822dd11c1de4b6e851aa3a471500",
            "width" : 300
        }
    },
    {
        "id" : "0yU7VItpGPmPcvKmwLg0JT",
        "href" : "https://api.spotify.com/v1/albums/0yU7VItpGPmPcvKmwLg0JT",
        "name" : "The Endless River",
        "uri" : "spotify:album:0yU7VItpGPmPcvKmwLg0JT",
        "image": {
            "height" : 300,
            "url" : "https://i.scdn.co/image/b6c4be8aa8ed0ae0a866cac3fdb2b03ac245d993",
            "width" : 300
        }
    }
];
