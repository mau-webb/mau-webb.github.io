// Funktioner kan även vara variabelvärden
var anka = function (a, b) {
  return a + b;
};
console.log(anka(1, 2)); // Skriver ut "3"

// Det gör att de kan anropas lite hur som helst
var b = {
  name: "addition"
};
b["add"] = anka;
console.log(b.add(2, 3)); // Skriver ut "3"
