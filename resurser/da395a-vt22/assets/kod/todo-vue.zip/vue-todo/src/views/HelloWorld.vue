<script setup></script>

<template>
    <h2>Hallå Världen!</h2>
</template>

<style scoped>
h2 {
    color: red;
}
</style>