const messageBoxEl = document.querySelector("#message-box");

document.querySelector("#info").addEventListener("click", function(e) {
    messageBoxEl.className = e.target.id;
});

document.querySelector("#success").addEventListener("click", function(e) {
    messageBoxEl.className = e.target.id;
});

document.querySelector("#error").addEventListener("click", function(e) {
    messageBoxEl.className = e.target.id;
});


/*
// Alternativ lösning

const messageBoxEl = document.querySelector("#message-box");
const btns = document.querySelectorAll("button");

btns.forEach((el) => {
    el.addEventListener("click", (e) => {
        messageBoxEl.className = e.target.id;
    })
});
*/
