$("#add-btn").on("click", function() {
    const item = $("#new-item").val();

    $("#items").append(`<li>
        ${item}
    </li>`);
});

$("ul").on("click", "li", function() {
    $(this).remove();
});