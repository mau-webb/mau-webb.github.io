const a = 1; // Kan inte omdeklareras
//a = 2;       // Fungerar inte, redan deklarerad!

const teacher = {
  name: "Johan",
  salary: 10000,
  colleague: {
    name: "Anton",
    younger: true
  }
};

//teacher = "Sebastian"; // Går inte, redan definierad!
console.log(teacher);
teacher.name = "Sebastian"; // Helt okej, dock!
console.log(teacher);
