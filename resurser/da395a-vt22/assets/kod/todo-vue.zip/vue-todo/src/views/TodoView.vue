<script setup>
import TodoList from '../components/TodoList.vue';
</script>

<template>
    <TodoList />
</template>

<style scoped></style>