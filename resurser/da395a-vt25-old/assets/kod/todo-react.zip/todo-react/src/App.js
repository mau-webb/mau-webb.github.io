import TodoList from './TodoList';

function App() {
  return (
    <div class="container">
      <h1>Välkommen till Vanilla JS-versionen!</h1>
      <TodoList />
    </div>
  );
}

export default App;
