$(".section-1").show();

$("nav li").on("click", function() {
    const section = $(this).attr("id");

    $("section").slideUp();
    $(`.${section}`).slideDown();

    $("nav li").removeClass("chosen");
    $(this).addClass("chosen");
});