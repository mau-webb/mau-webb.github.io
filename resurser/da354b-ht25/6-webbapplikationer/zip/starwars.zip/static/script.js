$(document).on("ready", function(){
	$("input[type='radio']").on("change", function(){
		$("input[type='radio']").parent().removeClass("chosen");
		if($(this).prop("checked") == true){
			$(this).parent().addClass("chosen");
		}
	})
});