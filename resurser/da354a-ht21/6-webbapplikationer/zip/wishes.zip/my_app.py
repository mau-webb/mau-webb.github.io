import json
from bottle import run, route, template, static_file, request, redirect

def read_wishes_from_file():
    try:
        my_file = open("storage/wishes.json", "r")
        wishes = json.loads(my_file.read())
        my_file.close()

        return wishes
    except:
        my_file = open("storage/wishes.json", "w")
        my_file.write(json.dumps([]))
        my_file.close()

        return []

@route("/")
def index():
    print(read_wishes_from_file())
    return template("index", wishes=read_wishes_from_file())

@route("/new-wish", method="POST")
def new_wish():
    wish = getattr(request.forms, "wish")
    link = getattr(request.forms, "link")
    price = getattr(request.forms, "price")

    wishes = read_wishes_from_file()
    wishes.append({
        "title": wish,
        "link": link,
        "price": price
    })

    my_file = open("storage/wishes.json", "w")
    my_file.write(json.dumps(wishes, indent=4))
    my_file.close()

    return redirect("/")

@route("/static/<filename>")
def static_files(filename):
    return static_file(filename, "static")

run(host="127.0.0.1", port=8000)
