/*
    jQuery - Ajax
*/
$("#joke-btn").on("click", function() {
    $.ajax({
        url: "https://api.chucknorris.io/jokes/random",
        dataType: "JSON"
    }).done(function(data){
        $("#joke").text(data.value);
    });
});

/*
    fetch - asynkrona anrop
*/
const jokeBtn = document.getElementById("joke-btn");
jokeBtn.addEventListener("click", fetchJoke);

async function fetchJoke() {
    const data = await fetch("https://api.chucknorris.io/jokes/random");
    const jsonData = await data.json();
    const jokeEl = document.getElementById("joke");
    jokeEl.textContent = jsonData.value;
}

/*
    fetch - callbacks
*/
const jokeBtn2 = document.getElementById("joke-btn");
jokeBtn2.addEventListener("click", function() {
    fetch("https://api.chucknorris.io/jokes/random").then(function(data) {
        return data.json();
    }).then(function(data) {
        const jokeEl2 = document.getElementById("joke");
        jokeEl2.textContent = data.value;
    });
});
