var a = 1; // Kan omdeklareras
var a = 2; // Helt okej, men konstigt

if (a == 2) {
  var language = "sv";
  console.log("We’re using " + language);
}
console.log(language); // Kommer att skriva ut ”sv”
