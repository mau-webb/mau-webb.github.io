const username = localStorage.getItem("name");

if (username === null) {
    const newName = prompt("Vad heter du?");
    localStorage.setItem("name", newName);
} else {
    alert(`Hej ${username}!`);
}



