﻿navigator.geolocation.getCurrentPosition(function(postion) {
    console.log(postion);
}, function(error) {
    console.log(error);
}, {})