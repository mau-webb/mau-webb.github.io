let ulList = document.querySelector("#items");

function deleteItem(e) {
    e.target.parentNode.parentNode.removeChild(e.target.parentNode);
}

document.querySelector("#add-item").addEventListener("click", function(e) {
    const item = window.prompt("Ange sak:");

    const li = document.createElement("li");
    const liTextNode = document.createTextNode(item);

    // Add text to <li>
    li.appendChild(liTextNode);

    const span = document.createElement("span");
    const spanTextNode = document.createTextNode("Delete");

    // Add delete-feature to <span>-element
    span.addEventListener("click", deleteItem);

    // Add text to <span>
    span.appendChild(spanTextNode);

    // Add <span> to <li>
    li.appendChild(span);

    // Add <li> to <ul>
    ulList.appendChild(li);

});