﻿navigator.geolocation.getCurrentPosition(function(position) {
    // Allt OK!
    console.log(position);
}, function(error) {
    // Något gick fel
}, {})