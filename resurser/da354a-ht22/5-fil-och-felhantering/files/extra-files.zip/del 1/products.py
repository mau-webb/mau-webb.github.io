def get_products_from_file():
    try:
        my_file = open("products.txt", "r")
        content = my_file.read()
        products = content.split("\n")

        products_list = []

        for product in products:
            product_info = product.split(";")

            try:
                p = {
                    "id": product_info[0],
                    "price": product_info[1],
                    "name": product_info[2],
                    "brand": product_info[3],
                    "color": product_info[4],
                    "in_stock": product_info[5]
                }

                products_list.append(p)
            except:
                pass
        
        my_file.close()
        
        return products_list
    
    except FileNotFoundError:
        my_file = open("products.txt", "w")
        my_file.close()

        return []


products = get_products_from_file()

headings = ["id", "pris", "namn", "märke", "färg", "lagerstatus"]
for heading in headings:
    print(f"{heading:<15}", end="")

print("")

for product in products:
    print(f"{product['id']:<15}{product['price']:<15}{product['name']:<15}{product['brand']:<15}{product['color']:<15}{product['in_stock']:<15}")


p = {
    "id": "5",
    "price": "199",
    "name": "USB-kabel",
    "brand": "Deltaco",
    "color": "black",
    "in_stock": "2000"
}

products.append(p)

print(products)

my_file = open("products.txt", "w")

for product in products:
    my_file.write(f"{product['id']};{product['price']};{product['name']};{product['brand']};{product['color']};{product['in_stock']}\n")

my_file.close()





"""
products = text.split("\n")

headings = ["id", "pris", "namn", "märke", "färg", "lagerstatus"]
for heading in headings:
    print(f"{heading:<15}", end="")

print("")
    
for product in products:
    values = product.split(";")
    for value in values:
        if value != "":
            print(f"{value:<15}", end="")

    print("")
"""
