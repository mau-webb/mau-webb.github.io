const { Builder, By, until } = require('selenium-webdriver');
require('geckodriver');

// This is the directory where the student's submission ends up.
// It can easily be changed to any URL.
const baseURL = 'file:///home/johan/Dokument/MAU/Kurser/Flerplattformsapplikationer/2022/Föreläsningar/Föreläsning 11/selenium/dist/';
// Change this to select another file to test.
const fileUnderTest = 'index.html';
const defaultTimeout = 10000;
let driver;
jest.setTimeout(1000 * 60 * 5);

// Three simple functions to ease DOM navigation
const getElementByName = async (driver, name, timeout = defaultTimeout) => {
    const element = await driver.wait(until.elementLocated(By.name(name)), timeout);
    return await driver.wait(until.elementIsVisible(element), timeout);
};

const getElementById = async (driver, id, timeout = defaultTimeout) => {
    const element = await driver.wait(until.elementLocated(By.id(id)), timeout);
    return await driver.wait(until.elementIsVisible(element), timeout);
};

const getElementByTag = async (driver, tag, timeout = defaultTimeout) => {
    const element = await driver.wait(until.elementLocated(By.tagName(tag)), timeout);
    return await driver.wait(until.elementIsVisible(element), timeout);
};

// This is run before any test.
beforeAll(async () => {
    driver = await new Builder().forBrowser('firefox').build();
    // This could be done elsewhere if you want to test multiple pages
    await driver.get(baseURL + fileUnderTest);
});
    
// This is run when all tests are done. If this isn't run, the Firefox session
// lingers, so make sure it actually runs.
afterAll(async() => {
    //await driver.quit();
}, defaultTimeout);

// This is a test suite. All tests in the suite share resources and the tests
// are run in sequence. You can create as may suites as you want.
describe('A Selenium test suite', () => {
    
    // This is how to describe a test within a test suite. You may define as
    // many tests as you want in a suite. You may even put other suites within
    // a suite.
    // Please note that you have to prepend each call to an asychronous
    // function with 'await', or the assertations won't work.
    test('there is a title with a predefined text', async () => {
        const title = await getElementByTag(driver, 'h1');
        const actual = await title.getText();
        expect(actual).toEqual("Här är en lista över katter");
    });
    
    test('it is possible to add a cat', async () => {
        const button = await getElementById(driver, "addCat");
        await button.click();
        let alert = await driver.switchTo().alert();
        await alert.sendKeys("Zorro");
        await alert.accept();
        await driver.manage().setTimeouts( { implicit: 1000 } );
        alert = await driver.switchTo().alert();
        await alert.sendKeys("Morsan");
        await alert.accept();
        await driver.manage().setTimeouts( { implicit: 1000 } );
        
        const listItem = await getElementByTag(driver, 'li');
        const actual = await listItem.getText();
        expect(actual).toEqual('Zorro, Morsan');
    });
}, defaultTimeout);
