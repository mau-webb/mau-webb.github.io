const counter = require('../src/counter');

test('there should be no cats in the beginning', () => {
	expect(counter.countCats()).toBeDefined();
	expect(counter.countCats()).toBe(0);
});

describe('When adding cats,', () => {
	it('a new cat should add exactly one cat and one owner', () => {
		const nbrOfCats = counter.countCats();
		counter.addCat("Kattfan", "Edgar");
		expect(counter.countCats()).toBe(nbrOfCats + 1);
	});
	
	it('merging arrays should always result in one array per cat', () => {
		counter.addCat("Garfield", "Jon");
		counter.addCat("Pejst", "Maya");
		counter.addCat("Cringer", "He-Man");
		expect(counter.countCats()).toBe(4);
		expect(counter.mergeArrays().length).toBe(4); //<= Fixat!
	});
});
