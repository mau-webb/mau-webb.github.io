/*
 * En closure-funktion kopplar samman data med en (eller flera) funktioner.
 * Det påminner lite om hur en objekt-orienterad klass fungerar.
 */
function create() {
  var name = 'Ujjal Kaur';    // Denna ligger i samma scope som printName()
  function printName() {
    console.log(name);        // Samma scope = åtkomst
  }
  return printName;
}
var f = create();             // Detta kommer att generera en ny closure åt oss
f();
