function getStars(nr_of_stars) {
    return "<img src='images/star.png' alt='Star'>".repeat(nr_of_stars);
}

$("#movie-list").on("click", ".delete-movie", function() {
    $(this).parent().remove();
});

$("#add-movie").on("submit", function(e) {
    e.preventDefault();

    const title = $("#title").val();
    const grade = $("#rating").val();

    if (title === "") {
        alert("Du måste ange en titel för att kunna spara filmen");
        return false;
    }

    if (grade === "0") {
        alert("Du måste ange ett betyg för att kunna spara filmen")
        return false;
    }

    const movie = `<li data-grade="${grade}" data-title="${title}">
        ${title}
        <img src="images/delete.png" alt="Delete movie" class="delete-movie">
        ${getStars(grade)}
    </li>`;

    $("#movie-list").append(movie);

    $(this).trigger("reset");
});