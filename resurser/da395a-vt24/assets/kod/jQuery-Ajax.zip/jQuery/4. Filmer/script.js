$("#menu button").on("click", function() {
    let id = $(this).attr("id");
    
    if (id == "all") {
        $("#movies li").show();
    } else {
        $("#movies li").hide();
        $(`#movies li[data-genre="${id}"]`).show();
    }
});