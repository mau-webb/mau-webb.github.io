import { Component } from '@angular/core';
import { TodoItemComponent } from '../todo-item/todo-item.component';
import { Todo } from '../todo';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent {
  todos: Todo[] = [
    {
      label: "Första punkten",
      id: 0
    },
    {
      label: "Andra punkten",
      id: 1
    }
  ];

  latestID: number = 0;
  todosLeft: number = 0;
  pluralString: string = "";

  constructor() {
    for (const todo of this.todos) {
      if (todo.id > this.latestID) {
        this.latestID = todo.id;
      }
    }
    this.updateInfoData();
  }

  maybeAddItem(event: Event): void {
    this.todos.push({
      label: (event.target as HTMLInputElement).value,
      id: ++(this.latestID)
    });
    this.updateInfoData();
  }

  deleteItem(id: number): void {
    this.todos = this.todos.filter((item) => item.id != id);
    this.updateInfoData();
  }

  updateInfoData(): void {
    this.todosLeft = this.todos.length;
    this.pluralString = this.todosLeft === 1 ? "punkt" :"punkter";
  }
}
