$("#get-joke").on("click", function() {
    $.ajax({
        url: "http://api.icndb.com/jokes/random",
        dataType: "JSON"
    }).done(function(data) {
        $("#joke").text(data.value.joke);
        $("#joke").fadeIn();
    }).fail(function(data) {
        console.log(data);
    });
});
