from bottle import redirect, run, route, template, static_file, request
import json

def read_wishes_from_file():
    try:
        my_file = open("wishes.json", "r")
        wishes = json.loads(my_file.read())
        my_file.close()

        return wishes
    except FileNotFoundError:
        my_file = open("wishes.json", "w")
        my_file.write(json.dumps([]))
        my_file.close()

        return []

def create_id(wishes):
    highest_id = 1
    for wish in wishes:
        if wish["id"] >= highest_id:
            highest_id = wish["id"] + 1
    
    return highest_id

@route('/')
def index():
    return template("index", wishes=read_wishes_from_file())

@route('/new-wish', method="post")
def create_wish():
    title = getattr(request.forms, "title")
    price = getattr(request.forms, "price")
    link = getattr(request.forms, "link")
    prio = getattr(request.forms, "prio")

    wishes = read_wishes_from_file()
    id = create_id(wishes)

    wishes.append({
        "title": title,
        "price": price,
        "link": link,
        "prio": prio,
        "id": id
    })

    try:
        my_file = open("wishes.json", "w")
        my_file.write(json.dumps(wishes, indent=4))
        my_file.close()
    except:
        print("Det gick inte att spara önskningarna")

    redirect("/")

@route('/static/<filename>')
def static_files(filename):
    return static_file(filename, root="static")

run(host="127.0.0.1", port=8080, reloader=True)