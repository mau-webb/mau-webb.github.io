from bottle import route, get, post, run, template, error, static_file, request, response, redirect
import json
import datetime	

def get_votes():
	'''Returns an object (dictionary) with the results from file: "staic/standings.txt"
	
	The result is in JSON format, ex.
	{
		"empire": 13,
		"rebels": 9
	}
	
	Returns:
		str : The results
	'''
	try:
		# Opens the file "static/standings.txt" in "read" mode
		votes_file = open('static/standings.json', 'r')
		# Reads and converts the file content (JSON) to Python datatype (dictionary)
		votes = json.loads(votes_file.read())
		# Closes the file
		votes_file.close()
		# Return the votes
		return votes
	except:
		# Creates a new file called "standings.json"
		votes_file = open("static/standings.json", "w")
		# Writes the basic structure in JSON-format
		votes_file.write(json.dumps({"empire": 0, "rebels": 0}))
		# Returns the basic structure as a dictionary
		return {"empire": 0, "rebels": 0}

def get_disqus():
	'''Returns a list of comments, created from file: "staic/disqus.txt"
	
	Example result:
	[
		"The emperor;2015-11-28 22:55:00;We got cookies!",
		"Darth Vader;2015-11-29, 19:45:56;Luke, I'm your father."
	]
	
	Returns:
		str : The results
	'''
	try:
		# Opens the file "static/disqus.txt" in "read" mode
		disqus_file = open('static/disqus.json', 'r')
		# Reads and converts the file content (JSON) to Python datatype (list)
		disqusions = json.loads(disqus_file.read())
		# Closes the file
		disqus_file.close()
		# Returns the list of every lines in file
		return disqusions
	except:
		# Creates a new file called "disqus.json"
		disqus_file = open("static/disqus.json", "w")
		# Writes the basic structure in JSON-format
		disqus_file.write(json.dumps([]))
		# Returns the basic structure as an empty list
		return []

@route('/')
def index():
	'''Returns the start page
	
	Returns:
		template : index
	'''
	# Creates and returns the template "index" (views/index.tpl) with the current standings (votes)
	return template("index", votes=get_votes() )
	
@route('/vote', method='POST')
def vote():
	'''Register a vote, and returns the start page
	
	Notes:
		- The vote is sent by a from (method = POST) with the key "vote"
		- The vote is added to the file "static/standings.txt"
	
	Returns:
		template : index
	'''
	# Recives the vote send from a from (method=POST) by the key "vote"
	vote = request.forms.get("vote")
	# Get the current standing (votes)
	current_votes = get_votes()
	# If the vote is for empire
	if vote == "empire":
		# Add one vote to the empire
		current_votes["empire"] = current_votes["empire"] + 1
	# If the vote is for rebels
	else:
		# Add one vote to the empire
		current_votes["rebels"] = current_votes["rebels"] + 1
	# Opens the file "static/standings.txt" in "write" mode
	votes_file = open('static/standings.json', 'w')
	# Converts the standings dictionary (current_votes) to JSON-format and saves it to text file
	votes_file.write(json.dumps(current_votes))
	# Closes the file
	votes_file.close()
	# Redirects to the start page
	redirect("/")

@route('/disqus')
def disqus():
	'''Returns the disqus page
	
	Returns:
		template : disqus
	'''
	return template("disqus", posts=get_disqus())

@post('/disqus-post', method='POST')
def save_post():
	'''Register a new disqus post, and returns the disqus page
	
	Notes:
		- The disqus post is sent by a from (method = POST) with following keys
			name 	=> the author
			message => the disqus post
		- The disqus post is added to the file "static/disqus.json"
		- We also add the date/time when the post is created
	
	Returns:
		template : index
	'''
	# Recives the name send from a from (method=POST) by the key "name"
	name = getattr(request.forms, "name")
	# Recives the message send from a from (method=POST) by the key "message"
	message = getattr(request.forms, "message")
	# Create a timestamp - when the post is created (i.e. 2015-12-15 14:37:31)
	date_time = datetime.datetime.now().strftime("%Y-%m-%d, %H:%M:%S")

	posts = get_disqus()
	posts.append({
		"name": name,
		"message": message,
		"datetime": date_time
	})

	# Opens the file "static/disqus.json" in "write" mode
	disqus_file = open('static/disqus.json', 'w')

	disqus_file.write(json.dumps(posts, indent=4))
	# Closes the file
	disqus_file.close()
	# Creates and returns the template "disqus" (views/disqus.tpl) with the current disqus posts
	redirect("/disqus")

@route('/static/<filename:path>')
def server_static(filename):
	'''Handles the routes to our static files
	
	Returns:
		file : the static file requested by URL	
	'''
	return static_file(filename, root='static')


@error(404)
def error404(error):
	'''Makes a pretty error page, when page is not found (error 404)
	
	Returns:
		template : error
	'''
	return template("error")

# Start our web server
run(host='127.0.0.1', port=8080, debug=False, reloader=True)
