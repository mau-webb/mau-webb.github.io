$("#play").on("click", function() {
    const video = document.getElementById("video");
    console.log(video);
    video.play();
    video.muted = true;
});
