// Sedan, let/const
let alef = 11; // Synlig överallt, eftersom den tillhör det globala scopet

/*
 * Eftersom alef ligger i det globala scopet, kommer det här att fungera bra.
 */
function alef_1() {
  console.log(alef);
}

/*
 * Här deklarerar vi en variabel som inte blir synlig utanför funktionen: vårt
 * lokala scope är begränsat till funktionen bet_1
 */
function bet_1() {
  let bet = 13;
}

/*
 * Den här funktionen kommer inte att fungera, eftersom bet inte är deklarerad
 * i det lokala scopet.
 */
function bet_2() {
  console.log(bet);
}

/*
 * Det här kommer att fungera bra
 */
function bet_3() {
  let bet = 17;
  console.log(bet);
}

/*
 * Här visar vi att let-definierade variabler inte kan omdefinieras inom sitt
 * scope, men väl inom ett annat block.
 */
function gimel_1() {
  console.log("gimel_1:");
  let gimel = 19;
  console.log(gimel);
  if (true) {
    let gimel = 23; // Här skapar vi en ny, temporär gimel-variabel
  }
  console.log(gimel);
}

alef_1();         // Det här kommer att fungera utmärkt!
bet_1();          // Det här kommer att fungera utmärkt!
bet_2();          // Det här kommer att krascha
bet_3();          // Det här kommer att fungera utmärkt!
gimel_1();        // Det här kommer att fungera utmärkt!
