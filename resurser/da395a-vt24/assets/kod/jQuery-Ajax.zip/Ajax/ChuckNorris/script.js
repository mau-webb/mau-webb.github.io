// Med jQuerys Ajax-funktion
$("#joke-btn").on("click", function() {
    $.ajax({
        url: "http://api.icndb.com/jokes/random?exclude=[explicit]",
        dataType: "JSON"
    }).done(function(data) {
        $("#joke").text(data.value.joke);
    });
});

/*
    Alternativ lösning med fetch

$("#joke-btn").on("click", function() {
    fetchJoke();
    fetch("http://api.icndb.com/jokes/random?exclude=[explicit]").then(data => {
        data.json().then(jsonData => {
            $("#joke").text(jsonData.value.joke);
        });
    });
});

*/

/*
    Alternatvi lösning med fetch (2)
    
$("#joke-btn").on("click", fetchJoke);

async function fetchJoke() {
    let data = await fetch("http://api.icndb.com/jokes/random?exclude=[explicit]");
    let jsonData = await data.json();
    $("#joke").text(jsonData.value.joke);
}
*/