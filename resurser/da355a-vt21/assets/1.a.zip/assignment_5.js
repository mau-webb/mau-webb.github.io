function main() {
    console.log("Uppgift 5.");

    let countries = ["Sweden", "Denmark", "Finland", "Norway"];
    
    // Er lösning
    let den = countries[1].substring(0, 3);
    let totalSum = countries.reduce((a, b) => a + b.length, 0);
    let averageLength = totalSum/countries.length;

    console.log(den);
    console.log(averageLength);
}

main();

// Notera att raden nedan behövs för den automatiska rättningen av uppgiften
exports.main = main;