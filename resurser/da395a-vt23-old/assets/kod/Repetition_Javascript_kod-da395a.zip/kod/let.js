let a = 1; // Kan inte omdeklareras
let a = 2; // Fungerar inte, du kommer att få ett fel
a = 2;     // Fast det här är helt okej!

if (a == 2) {
  let language = "sv";
  console.log("We’re using " + language);
}
console.log(language); // Ger ett fel, ReferenceError
