import * as catCounter from './counter.js';

window.onload = function () {
	let addCatElement = document.getElementById('addCat');
	let countCatsElement = document.getElementById('countCats');
	let mergeElement = document.getElementById('merge');
	let catsElement = document.getElementById('cats');
	let lastCoupleElement = document.getElementById('lastCouple');
	
	addCatElement.addEventListener("click", function () {
		let cat = prompt("Vad heter katten?");
		let owner = prompt("Vem äger katten?");
		let catBullet = document.createElement("li");
		
		catCounter.addCat(cat, owner);
		catBullet.appendChild(document.createTextNode(cat + ", " + owner));
		catsElement.appendChild(catBullet);
	});
	
	lastCoupleElement.addEventListener("click", function () {
		console.log(catCounter.getLastCouple());
	});
	
	countCatsElement.addEventListener("click", function () {
		console.log("Antal katter: " + catCounter.countCats());
	});
	
	mergeElement.addEventListener("click", function () {
		console.log(catCounter.mergeArrays());
	});
};
