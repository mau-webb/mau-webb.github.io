$("#images > img").on("click", function() {
    var imgSrc = $(this).attr("src");
    var imgAlt = $(this).attr("alt");

    $("body").prepend(`
        <div class="modal">
            <figure>
                <img src="${imgSrc}" alt="${imgAlt}">
                <figcaption>${imgAlt}</figcaption>
            </figure>
        </div>
    `)
});

$("body").on("click", ".modal", function() {
    $(this).remove();
})