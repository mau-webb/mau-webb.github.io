$("#tip-btn").on("click", function() {
    $.ajax({
        url: "http://localhost:8080/date.php"
    }).done(function(data) {
        $("#tip").text(data);
    });
});