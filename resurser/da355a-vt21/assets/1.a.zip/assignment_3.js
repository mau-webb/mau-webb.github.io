function main() {
    console.log("Uppgift 3.");

    // Er lösning
    let itsLearning = "It's Learning".substring(5);
    let goodParts_1 = "JavaScript: The Good Parts".substring(16);
    let goodParts_2 = "JavaScript: The Good Parts".substring(16, 20);
    let eloquentJS = "Eloquent JavaScript".substring(5, 13);
    console.log(itsLearning.toUpperCase());
    console.log(goodParts_1.toLowerCase());
    console.log(goodParts_2.toUpperCase());
    console.log(eloquentJS);
}

main();

// Notera att raden nedan behövs för den automatiska rättningen av uppgiften
exports.main = main;