<script setup>
import { ref, computed, onMounted } from 'vue';
import TodoItem from './TodoItem.vue';

// Reaktiva värden
const todos = ref([
    {
        title: "Första saken",
        id: 0
    },
    {
        title: "Andra saken",
        id: 1
    }
]);

const nbrOfItems = computed(() => todos.value.length );
const todoString = computed(() => {
    return todos.value.lengt == 1 ? 'punkt' : 'punkter';
});

// Ej reaktiva värden
let latestID = 0;

onMounted(() => {
    console.log("Så här ser vår lista ut:");
    console.log(todos.value);
    for (const todo of todos.value) {
        if (todo.id > latestID) {
            latestID = todo.id;
        }
    }
    console.log(latestID);
});

// Funktioner för att lägga till och ta bort att göra-poster
function maybeAddItem(event) {
    if (event.keyCode == 13) {
        todos.value.push({
            title: event.target.value,
            id: ++latestID
        });
    }
}

function removeTodo(id) {
    todos.value = todos.value.filter(todo => todo.id != id);
}

</script>

<template>
    <h2>Att göra</h2>
    <input type="text" id="new-todo" placeholder="Vad ska göras?" class="form-control" @keyup="maybeAddItem">
    <ul id="todos" class="list-group">
        <TodoItem v-for="todo in todos" :label="todo.title" :id="todo.id" :key="`item-${todo.id}`" @remove-todo="removeTodo"></TodoItem>
    </ul>
    <span id="nbr-of-todos"><strong>{{ nbrOfItems }}</strong> {{ todoString }} kvar att göra</span>
</template>