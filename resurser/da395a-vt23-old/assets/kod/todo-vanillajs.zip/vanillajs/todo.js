let todos = [
    {
        title: "Första saken",
        id: 1
    }
];
let latestID = 1;

document.querySelector("#new-todo").addEventListener("keyup", function (event) {
    if (event.keyCode == 13) {
        let todo = {
            title: event.target.value,
            id: ++latestID
        };
        todos.push(todo);
        event.target.value = "";
        
        renderTodos();
    }
});

function renderTodos() {
    document.querySelector("#todos").innerHTML = "";

    for (const todo of todos) {
        document.querySelector("#todos").innerHTML += `
            <li class="list-group-item">
                <label>${todo.title}</label>
                <button class="btn btn-sm btn-danger float-end" data-id="${todo.id}">X</button>
            </li>
        `;
    }

    const deleteButtons = document.querySelectorAll(".btn-danger");
    for (const button of deleteButtons) {
        button.addEventListener("click", function (event) {
            todos = todos.filter(todo => todo.id != event.target.getAttribute("data-id"));
            renderTodos();
        });
    }

    const todoString = todos.length == 1 ? "punkt" : "punkter";
    document.querySelector("#nbr-of-todos").innerHTML = `
        <strong>${todos.length}</strong> ${todoString} kvar att göra.
    `;
};

renderTodos();
