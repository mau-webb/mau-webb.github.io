function main() {
    console.log("Uppgift 2.");

    // Er lösning
    console.log("Tisdag".substring(0, 3));
    console.log("Hamburgare".substring(3, 10));
    console.log("I'll be back!".substring(5, 12));
}

main();

// Notera att raden nedan behövs för den automatiska rättningen av uppgiften
exports.main = main;