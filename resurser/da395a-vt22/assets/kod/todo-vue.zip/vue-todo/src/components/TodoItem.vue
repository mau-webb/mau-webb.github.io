<script setup>
defineProps({
    label: {
        type: String,
        required: true
    },
    id: {
        type: String,
        required: true
    }
});
</script>

<template>
    <li class="list-group-item">
        <label>{{ label }}</label>
        <button @click="$emit('removeTodo', id)" class="btn btn-sm btn-danger float-end" :data-id="id">X</button>
    </li>
</template>