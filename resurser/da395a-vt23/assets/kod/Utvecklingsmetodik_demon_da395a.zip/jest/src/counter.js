const _ = require('underscore');

let catNames = [];
let catOwners = [];

// Spara en katt
exports.addCat = function (cat, owner) {
	catNames.push(cat);
	catOwners.push(owner);
};

// Räkna antalet katter
exports.countCats = function () {
	return catNames.length;
};

// Slå samman de båda vektorerna
exports.mergeArrays = function () {
	return _.zip(catNames, catOwners);
}

// Få ut det senaste katt- och ägarparet
exports.getLastCouple = function () {
	return [_.last(catNames), _.last(catOwners)];
};
