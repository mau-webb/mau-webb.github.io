$("#nr-1, #nr-2").on("keyup", function() {
    if ($("#nr-1").val() !== "" && $("#nr-2").val() !== "") {
        const result = parseInt($("#nr-1").val()) * parseInt($("#nr-2").val());
        $("#result").val(result);
    } else {
        $("#result").val("");
    }
});