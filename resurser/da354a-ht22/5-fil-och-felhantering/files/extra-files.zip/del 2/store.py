def main():
    '''
    Huvudfunktionen i programmet som hantera välkomnande av användaren,
    inläsning av produkter från vår textfil "products.text" samt menyn i programmet.
    '''
    # 1. Skriva ut en välkomstfras
    welcome()

    # 2. Läsa in alla produkter från en text-fil
    file_name = "products.txt"
    products = read_products_from_file(file_name)

    # 3. Skriver ut menyn - och beroende på vad användaren väljer - visar/lägger till/tar bort produkter (eller avslutar programmet)
    while True:
        print_menu()
        user_choice = input("Ange val: ")

        if user_choice == "1":
            print_products(products)
        elif user_choice == "2":
            add_product(products)
        elif user_choice == "3":
            pass # Inte implementerad än
        elif user_choice == "4":
            save_products_to_file(file_name, products)
        elif user_choice == "0":
            break
        else:
            print("Du valde inte ett giltigt alternativ, försök igen.")

def save_products_to_file(file_name, products):
    '''
    Sparar våra produkter till given fil

    Args:
        file_name (str) : Sökvägen till den fil som ska användas
        products (list) : En lista innehållandes strängar (produkter) som ska sparas
    '''
    my_file = open(file_name, "w")
    
    for product in products:
        my_file.write(f"{product['id']};{product['price']};{product['name']};{product['brand']};{product['color']};{product['in_stock']}\n")

    my_file.close()
    print("\nProdukterna är nu sparade i filen!")
    

def add_product(products):
    '''
    Lägger till en produkt i vår produktlista

    Args:
        products (list) : En lista innehållandes strängar (produkter)
    '''
    print("\nLägg till en produkt")
    print("-"*40)

    p = {
        "id": input("Ange id: "),
        "price": input("Ange pris: "),
        "name": input("Ange namn: "),
        "brand": input("Ange märke: "),
        "color": input("Ange färg: "),
        "in_stock": input("Ange lagerstatus: ")
    }
    
    products.append(p)


def print_products(products):
    '''
    Skriver ut alla produkterna i vår produktlista

    Args:
        products (list) : En lista innehållandes strängar (produkter)
    '''
    print("\nProdukter")
    print("*"*40)
    
    headings = ["id", "pris", "namn", "märke", "färg", "lagerstatus"]
    for heading in headings:
        print(f"{heading:<15}", end="")

    print("")

    for product in products:
        print(f"{product['id']:<15}{product['price']:<15}{product['name']:<15}{product['brand']:<15}{product['color']:<15}{product['in_stock']:<15}")
          

def print_menu():
    '''
    Skriver ut programmets meny
    '''
    print("\nMenu")
    print("-"*40)
    print("1) Skriv ut alla produkter")
    print("2) Lägg till en produkt")
    print("3) Ta bort en produkt")
    print("4) Spara produkterna till filen")
    print("0) Avsluta")

def read_products_from_file(file_name):
    try:
        my_file = open(file_name, "r")
        content = my_file.read()
        products = content.split("\n")

        products_list = []

        for product in products:
            product_info = product.split(";")

            try:
                p = {
                    "id": product_info[0],
                    "price": product_info[1],
                    "name": product_info[2],
                    "brand": product_info[3],
                    "color": product_info[4],
                    "in_stock": product_info[5]
                }

                products_list.append(p)
            except:
                pass
        
        my_file.close()
        
        return products_list
    
    except FileNotFoundError:
        my_file = open("products.txt", "w")
        my_file.close()

        return []
    

def welcome():
    '''
    Skriver ut välkomstmeddelande
    '''
    print("-"*40)
    print("Antons teknikbutik")
    print("-"*40)

# Kör vårt program genom funktionen "main"
main()
