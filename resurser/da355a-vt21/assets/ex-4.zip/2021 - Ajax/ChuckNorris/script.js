$("#joke-btn").on("click", function() {
    $.ajax({
        url: "http://api.icndb.com/jokes/random?exclude=[explicit]",
        dateType: "JSON"
    }).done(function(data) {
        $("#joke").text(data.value.joke);
    }).fail(function(data) {
        console.log(data);
    });
});