function main() {
    console.log("Uppgift 4.");

    let numbers = [128, 256, 512, 1024, 2048];
    // Er lösning
    let totalSum = numbers.reduce((a, b) => a + b);
    let average = totalSum / numbers.length;

    // Skriv ut summan av alla element
    console.log(totalSum);

    // Skriv ut medelvärdet av alla element
    console.log(average);    
}

main();

// Notera att raden nedan behövs för den automatiska rättningen av uppgiften
exports.main = main;