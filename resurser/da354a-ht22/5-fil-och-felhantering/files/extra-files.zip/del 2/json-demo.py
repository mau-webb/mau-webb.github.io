import json

"""
people = [
    {
        "name": "Anton",
        "age": 32,
        "city": "Lund"
    },
    {
        "name": "Johan",
        "age": 41,
        "city": "Malmö"
    }
]

my_file = open("people.json", "w")
my_file.write(json.dumps(people, indent=4))
my_file.close()

"""

my_file = open("people.json", "r")
people = my_file.read()
my_file.close()

people_as_list = json.loads(people)

for p in people_as_list:
    print(p["name"])
