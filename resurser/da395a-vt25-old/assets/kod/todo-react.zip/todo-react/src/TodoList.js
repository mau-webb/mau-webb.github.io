import React, { useState, useRef } from 'react';
import TodoItem from './TodoItem';

export default function TodoList() {
    const [todos, setTodos] = useState([
        {
            id: 1,
            title: "Första saken"
        }
    ]);
    const inputRef = useRef();

    function addItem(event) {
        if (event.keyCode === 13) {
            const newId = todos.length > 0 ? todos[todos.length - 1].id + 1 : 1;

            setTodos([...todos, {
                id: newId,
                title: inputRef.current.value
            }]);

            inputRef.current.value = "";
        }
    }

    function deleteItem(id) {
        setTodos(todos.filter((item)  => item.id != id));
    }

    return (
        <div>
            <h2>Att göra:</h2>
            <input className="form-control" placeholder="Vad ska göras?" ref={inputRef} onKeyUp={addItem} />
            <ul className="list-group">
                { todos.map(todo => <TodoItem key={todo.id} item={todo} deleteItem={deleteItem} />) }
            </ul>
            <strong>{ todos.length }</strong> { todos.length === 1 ? 'punkt' : 'punkter' } kvar att göra.
        </div>
    );
}