// Först, var
var alfa = 1;     // Synlig överallt, eftersom den tillhör det globala scopet

/*
 * Eftersom alfa ligger i det globala scopet, kommer det här att fungera bra.
 */
function alfa_1() {
  console.log("alfa_1:");
  console.log(alfa);
}

/*
 * Här deklarerar vi en variabel som inte blir synlig utanför funktionen: vårt
 * lokala scope är begränsat till funktionen beta_1
 */
function beta_1() {
  var beta = 2;
}

/*
 * Den här funktionen kommer inte att fungera, eftersom beta inte är deklarerad
 * i det lokala scopet.
 */
function beta_2() {
  console.log("beta_2:");
  console.log(beta);
}

/*
 * Det här kommer att fungera bra
 */
function beta_3() {
  console.log("beta_3:");
  var beta = 3;
  console.log(beta);
}

/*
 * Här visar vi att var-definierade variabler kan omdefinieras inom sitt scope.
 */
function gamma_1() {
  console.log("gamma_1:");
  var gamma = 5;
  console.log(gamma);
  if (true) {
    var gamma = 7; // Här ändrar vi värdet på gamma
  }
  console.log(gamma);
}

alfa_1();          // Det här kommer att fungera utmärkt!
beta_1();          // Det här kommer att fungera utmärkt!
beta_2();          // Det här kommer att krascha
beta_3();          // Det här kommer att fungera utmärkt!
gamma_1();         // Det här kommer att fungera utmärkt!
