/*
 * Ett lite mer avancerat exempel som beskriver en vanlig morgon i det
 * holmbergska hemmet efter lite för lång jobbnatt.
 */
var snooze = (function () {  // Här tilldelar vi snooze en closure direkt
  var snoozes = 0;           // Det här syns inte utåt = privat
  
  function snooze(minutes) { // Den här syns inte utåt = privat
    snoozes += minutes;
  }
  
  return {                   // Det är det här objektet med funktioner som syns utåt
    justOneMore: function() {
      snooze(5);
    },
    
    howLongDidISnooze: function() {
      console.log(snoozes + " minutes");
    }
  }
})();

snooze.justOneMore();
snooze.justOneMore();
snooze.justOneMore();
snooze.howLongDidISnooze();
