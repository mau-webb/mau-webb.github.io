// `toggleNextElement` har som uppgift att visa eller dölja ett elements
// kommande syskon. I vårt fall när vi klickar på en rubrik (h2) ska det
// nästkommande syskonet (section) visas eller döljas.
function toggleNextElement(e) {
    // 1. Leta upp det nästkommande syskonet
    const nextEl = e.target.nextElementSibling;
    // 2. Kontrollera om det visas eller döljs
    // 3. Om det visas, dölj det, annars tvärtom
    if (nextEl.style.display == "none") {
        nextEl.style.display = "block";
    } else {
        nextEl.style.display = "none";
    }
}

// `start` har som uppgift att dölja allt innehåll för våra artiklar och
// ser till att funktionen `toggleNextElement` körs när en användare
// klickar på rubrikerna (h2)
function start() {
    // 1. Hämta alla rubriker (h2) och spara dom i en variabel
    const h2 = document.querySelectorAll("h2");
    // 2. Loopa igenom alla dessa rubriker och:
    h2.forEach((el) => {
        // 2a. Dölj allt innehåll (section) som ligger som det nästkommande
        //     syskonet till rubriken
        el.nextElementSibling.style.display = "none";
        // 2b. Lägg till en event-lyssnar för att ange att funktionen
        //     `toggleNextElement` ska köras när en användare klickar
        //     på en rubrik.
        el.addEventListener("click", toggleNextElement);
    })
}

// Kör våran `start` funktion
start();