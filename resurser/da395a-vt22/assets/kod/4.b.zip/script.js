// Vi kommer fylla på denna i steg 2.
let options = {
        // Försök tvinga enheten till en så precis position som möjligt
        enableHighAccuracy: true,
        // Maximal tid i millisekunder som enheten har på sig att ge oss en position
        timeout: 10000,
        // Hur länge vår position får tillfälligt lagras (millisekunder)
        maximumAge: 500
};

function success(position) {
    // Ta en titt i er webbkonsol och se vad den innehåller.
    console.log("This is our position: ", position);

    const coords = position.coords;

    $("#longitude").text(coords.longitude);
    $("#latitude").text(coords.latitude);
    $("#accuracy").text(coords.accuracy);
    $("#speed").text(coords.speed);
    $("#altitude").text(coords.altitude);
    $("#accuracy-altitude").text(coords.altitudeAccuracy);

    const speedCointainer = $("#speed-container");
    const currentSpeed = $("#currect-speed");

    if (!isNaN(coords.speed)) {
        speedCointainer.show();
        const speed = (coords.speed * 3.6).toFixed(2);
        currentSpeed.text(`${speed} km/h`);

        if (speed < 4) {
            speedCointainer.attr("class", "alert alert-danger");
        } else if (speed < 10) {
            speedCointainer.attr("class", "alert alert-warning ");
        } else {
            speedCointainer.attr("class", "alert alert-success");
        }
    } else {
        speedCointainer.hide();
    }
}

function error(err) {
    console.warn("Something went wrong: ", err.message);
}

// Skicka med våra funktioner och inställningar,
// dessa kommer sedan anropas när en position försöker fastställas.
navigator.geolocation.getCurrentPosition(success, error, options);

// Skicka med våra funktioner och inställningar,
// dessa kommer sedan anropas kontinuerligt medan vi rör på oss.
let watchID = navigator.geolocation.watchPosition(success, error, options);