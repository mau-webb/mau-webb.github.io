$("#search-movie").on("keyup", function(){
    $("#movies").html("");

    if ($(this).val().length >= 3) {
        $.ajax({
            url: "http://www.omdbapi.com/",
            data: {
                apikey: "7c75e03b",
                s: $(this).val()
            }
        }).done(function(data) {
            if (data.Response === "True") {
                const movies = data.Search;
                
                movies.forEach(movie => {
                    $("#movies").append(`
                    <li>
                        <img src="${movie.Poster}" alt="${movie.Title} - Poster">
                        ${movie.Title}
                        <span>${movie.Year}</span>
                    </li>
                    `);
                });
            }
        });
    }
});