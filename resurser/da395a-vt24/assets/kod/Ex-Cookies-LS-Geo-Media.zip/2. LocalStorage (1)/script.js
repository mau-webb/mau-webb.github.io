const name = localStorage.getItem("name");

if (name === null) {
    const newName = prompt("Vad heter du?");
    localStorage.setItem("name", newName);
} else {
    alert(`Hej ${name}`);
}