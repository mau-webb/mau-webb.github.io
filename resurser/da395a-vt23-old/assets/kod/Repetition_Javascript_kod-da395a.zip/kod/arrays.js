var a = new Array();
a[0] = 1;
a[1] = "two";
a.push(3);
console.log(a); // Skriver ut "[1, "two", 3]"

var b = [1, "two", 3]; // Likadan som a!
console.log(b);  // Skriver ut "[1, "two", 3]"
