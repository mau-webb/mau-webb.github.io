$("#tip-btn").on("click", function() {
    $.ajax({
        url: "http://localhost:1234/date.php"
    }).done(function(data) {
        $("#tip").text(data);
    }).fail(function(data) {
        console.log(data);
    });
});